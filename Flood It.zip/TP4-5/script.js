const couleursDisponibles = [];

function genererCouleurs(N) {
    couleursDisponibles.length = 0;
    for (let i = 0; i < N; i++) {
        couleursDisponibles.push(`hsl(${Math.random() * 360}, 100%, 50%)`);
    }
}

function startGame(L, N, modeDefi) {
    genererCouleurs(N);

    const grille = document.getElementById('grille');
    const palette = document.getElementById('palette');
    const message = document.getElementById('message');

    let coups = 0;
    let limiteCoups = modeDefi ? 2 * L : Infinity;

    document.getElementById('coups').textContent = coups;

    grille.innerHTML = '';
    grille.style.display = 'grid';
    grille.style.gridTemplateColumns = `repeat(${L}, 40px)`;
    grille.style.gridGap = '2px';

    const cases = [];
    for (let i = 0; i < L; i++) {
        cases[i] = [];
        for (let j = 0; j < L; j++) {
            const div = document.createElement('div');
            div.classList.add('case');
            div.style.backgroundColor = couleursDisponibles[Math.floor(Math.random() * N)];
            div.dataset.x = i;
            div.dataset.y = j;
            div.addEventListener('click', (e) => choisirCouleur(e, cases, L, modeDefi, limiteCoups));
            grille.appendChild(div);
            cases[i][j] = div;
        }
    }

    palette.innerHTML = '';
    couleursDisponibles.forEach(couleur => {
        const bouton = document.createElement('button');
        bouton.classList.add('couleur-btn');
        bouton.style.backgroundColor = couleur;
        bouton.onclick = () => selectionnerCouleur(couleur);
        palette.appendChild(bouton);
    });
}

let couleurSelectionnee = null;

function selectionnerCouleur(couleur) {
    couleurSelectionnee = couleur;
}

function choisirCouleur(event, cases, L, modeDefi, limiteCoups) {
    if (!couleurSelectionnee) return;

    const x = parseInt(event.target.dataset.x);
    const y = parseInt(event.target.dataset.y);
    const couleurInitiale = cases[x][y].style.backgroundColor;

    function remplir(x, y) {
        if (x < 0 || y < 0 || x >= L || y >= L) return;
        if (cases[x][y].style.backgroundColor !== couleurInitiale) return;
        cases[x][y].style.backgroundColor = couleurSelectionnee;
        remplir(x - 1, y);
        remplir(x + 1, y);
        remplir(x, y - 1);
        remplir(x, y + 1);
    }

    remplir(x, y);
    let coups = parseInt(document.getElementById('coups').textContent) + 1;
    document.getElementById('coups').textContent = coups;

    if (verifierVictoire(cases, L)) {
        message.textContent = 'Bravo, vous avez gagné !';
    } else if (modeDefi && coups >= limiteCoups) {
        message.textContent = 'Dommage, vous avez dépassé la limite de coups !';
    }
}

function verifierVictoire(cases, L) {
    return cases.flat().every(cell => cell.style.backgroundColor === cases[0][0].style.backgroundColor);
}

function restartGame() {
    location.reload();
}
